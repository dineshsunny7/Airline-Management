
<html>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
<style>
body{
	margin:0px;
	padding:0px;
	background-size:cover;
	background-image:url("x.png");
}
.check
{
	background:black;
	height:753px;
	opacity:0.75;
}
.re
{
	background:black;
	height:200px;
	color:white;
	width:900px;
	padding:90px;
	position:relative;
	top:7%;
	left:20%;
}
i:hover
{
	cursor:pointer;
	transform:scale(1.15);
	
}
i
{
	
	position:relative;
	left:80%;
}
.mov
{
	display:inline;
	position:relative;
	left:35%;
}
form{display:inline;}
</style>
<div class="check">
<div class="re">
<span style="font-family:courier new;font-size:30px;">
<div class="mov"><form action="http://localhost/Takeoff/home/index.php" method="post"><button name="contact" value="1" style="background:black;color:yellow;padding:10px;border:0 solid black;opacity:8.9;"><a href=""><i class="fas fa-3x fa-times"></i></a></button></form></div>
<br><br>
<span style="background:#0000ff;padding:8px;">CEO</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;praveenjampala@tkairlines.com<br>
<span style="background:#0000ff;padding:8px;">President</span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;saikumar@tkairlines.com<br>
<span style="background:#0000ff;padding:8px;">Vice President</span>&nbsp;&nbsp;&nbsp;manikanta@tkairlines.com<br>
<span style="background:#0000ff;padding:8px;">Manager</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;sunny@tkairlines.com<br><br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="background:red;opacity:48.9;padding:7px;">Branch</span><br><br>
HYDERABAD  &nbsp;&nbsp;&nbsp;&nbsp;+040 6436747123<br>
MUMBAI  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+040 6436747124<br>
CHENNAI  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+040 6436747125<br>
KOCHI  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+040 6436747126<br>
DELHI  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+040 6436747127<br>
</span>
</div>
</div>
</html>