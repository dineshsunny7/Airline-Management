
<html >
<head>
<title>Airline management</title>
  <meta charset="utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
	<link rel="stylesheet" href="hstyle.css">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>


<body >

<div class="all">
<div class="header1">
<div class="combine clearfix">
<div class="left">
<img id="bomma" src="pep.png">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font face="courier new" size="5px" color="white"><b>#<i><b>T</b></i> A K E OFF</b> <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AIRLINES<br></font>

</div>
<div class="right">
  <input id="we" type="button" value="Home">
<a href="about_us.php"><input id="we" type="button" value="About Us"></a>
<a href="mydata.php"><input id="we" type="button" value="My Bookings"></a>
<a href="http://localhost/takeoff/home/cus.php"><input id="we" type="button" value="Contact Us"></a>
</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


<button id="say"  name="logout" value="1"><a  href="1.php"><i class="fas fa-sign-out-alt fa-2x" style="margin-top:6px;color:black;" aria-hidden="true" ></i></a></button>
</div>
</div>
</div>
<br><br><br><br><br><br>
<div class="overlay">
<br>
<form action="Search\search_flight.php" method="post"><button id="di"  value="Book Now">Book NOW</button></form>
</div>
<br>

<div class="hi1">
<br><br><br><br><br><br>
<span style="color:white;font-size:30px;font-family:Segoe Script;"></span><br><br><br>
<img id="dhoni" style="height:250px;border:0px solid black;border-radius:40px; cursor:pointer;box-shadow: 0 5px 15px -5px white;hover:transform:scale(1.5);"src="dhoni.jpg" >
<div class="rey420"><br><br>
<span style="color:#F2AA4CFF;background:#195190FF;padding:10px;position:relative;top:3%;font-family:Segoe Script;font-size:24px;">&nbsp;&nbsp;<b>I love travelling in  TAKE OFF AIRLINES</b></span>
</div>
</div>


<div class="hi11">
<img id="kohli" style="height:250px;border:0px solid black;border-radius:40px; cursor:pointer;box-shadow: 0 5px 15px -5px white;hover:transform:scale(1.5);"src="kohli.jpg" >
<div class="rey4201"><br><br><br>
<span style="color:#FAEBEFFF;background:#9E1030FF;padding:10px;position:relative;top:3%;font-family:Segoe Script;font-size:24px;">&nbsp;&nbsp;<b>Take OFF Airlnes made travelling simple</b></span>
</div>
</div>



<br>

<div class="hi1">
<br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br>
<img id="dhoni"  style="height:250px;border:0px solid black;border-radius:40px; cursor:pointer;box-shadow: 0 5px 15px -5px white;hover:transform:scale(1.5);"src="rajamouli.jpg" >
<div class="rey4202"><br><br>
<span id="operator" style="color:#00203FFF;background:#A2A2A1FF;padding:10px;position:relative;top:3%;font-family:Segoe Script;font-size:24px;">&nbsp;&nbsp;<b>Crew at its best #TAKEOFF AIRLINES</b></span>
</div>
</div>


<br><br><br>
<div class="hi11">
<img id="kohli" style="height:250px;border:0px solid black;border-radius:40px; cursor:pointer;box-shadow: 0 5px 15px -5px white;hover:transform:scale(1.5);" src="sushma.jpg" >
</div>

<div class="rey4201"><br><br><br>
<span style="color:black;background:skyblue;padding:10px;position:relative;top:3%;font-family:Segoe Script;font-size:24px;">&nbsp;&nbsp;<b>India's best airlines #TAKEOFF AIRLINES</b></span>
</div>
<br><br>
<div class="low">

    <div class="middle">
      <a class="btn" href="https://www.facebook.com/">
        <i class="fab fa-facebook-f "></i>
      </a>
      <a class="btn" href="https://twitter.com/login?lang=en">
        <i class="fab fa-twitter"></i>
      </a>
      <a class="btn" href="https://www.google.com/">
        <i class="fab fa-google"></i>
      </a>
      <a class="btn" href="https://www.instagram.com/">
        <i class="fab fa-instagram"></i>
      </a>
      <a class="btn" href="https://www.youtube.com/">
        <i class="fab fa-youtube"></i>

      </a>
	&nbsp;<br><b style="color:white;">&copy; reserved 2019-2022</b>

    </div>
	</div>
</div>
</body>
</html>
