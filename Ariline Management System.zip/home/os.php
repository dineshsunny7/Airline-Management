
<html>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
<style>
body{
	margin:0px;
	padding:0px;
	background-size:cover;
	background-image:url("x.png");
}
.check
{
	background:black;
	height:753px;
	opacity:0.75;
}
.re
{
	background:black;
	height:200px;
	color:white;
	width:1200px;
	padding:90px;
	position:relative;
	
	left:7%;
}
i:hover
{
	cursor:pointer;
	transform:scale(1.15);
	
}
i
{
	
	position:relative;
	left:45%;
}
</style>
<div class="check">
<div class="re">
<span style="font-size:20px;font-family:courier new;">
<a href="http://localhost/Takeoff/home/Search/avail.php#"><i class="fas fa-3x fa-times " style="color:red;"></i></a><br>
Flying with Takeoff Airlines is FUN, AFFORDABLE & EXCITING! As a low fare airline, Takeoff Airlines believes that flying should be a means of transport for everyone "flying for everyone". We aim to provide our passengers a totally unique flying experience that is safe, reliable and on-time with high level of passenger services.
Takeoff Airlines sells hot meals/snacks/refreshments and beverages on selected flights/ In Economy Class. Payment for the same will be accepted in INR only.

Pre Booked Spice Max Passengers are served a hot meal of choice.

For Business class passengers, selection of gourmet meals and beverages are available on-board. Variety of alcoholic beverages will be available only on select international flights.
Takeoff Airlines flies Boeing 737-800's and 737-900 ER's configured with single class with a seating capacity of 189 and 212 respectively. In addition to this Takeoff Airlines has added the Q400 NextGen turboprop aircraft from Bombardier, which can accommodate 78 passengers on a single class configuration.
Takeoff Airlines’s aim is to provide affordable efficient air travel. To achieve this objective, Takeoff Airlines will regularly add services to new destinations. Information about the same shall be conveyed to patrons via suitable means of communication.
Passengers may view latest flight schedule from ‘view our latest flight schedules’ link on the website.
Itinerary printouts with the name of the Passenger will be checked at the time of entering the terminal and at the check-in counter. Passengers who do not have the same are requested to collect the printouts from the Takeoff Airlines office located outside the departure terminal. This can be done on production of the booking reference number. A charge of INR 100/- will be levied for each print of an Itinerary / Ticket from any of the Takeoff Airlines Ticketing Counters / Offices across India (charges not applicable for fresh bookings). This fee is applicable only on requests for a print of an existing itinerary / ticket, already paid for. Please note the Itinerary Printout Fee towards re-printing of each Itinerary Ticket is reflected under the "Itinerary Printout Fee - INR 100" column on the printout. Passengers are reminded they need to maintain valid (ID) documents with them at airport check-in and throughout their journey. Business Class passengers will not be charged.


</div>
</div>
</html>