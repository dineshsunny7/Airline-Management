<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>ABOUT US </title>
<style type="text/css">
	p{
		text-align: center;
		font-family: courier new;
		font-size: 40px;
		color:red;
	}
     body{
     	background-image: url(abt.jpg);
                 background-size:full;
     }

	div
	{
		
		font-size: 25px;
	}
	textarea
	{
	color: white;
	position:relative;
	left:18%;
	border:1px solid #ffff00;
	border-radius:20px;
	background:rgba(51,51,51,.5);
	font-size:20px;
	resize:none;
	outline:none;
	}
	u{color:black;}
	button:hover
	{
cursor:pointer;
		border-radius: 10px;
		background-color: white;
	}
		button{
		position:relative;
		left:45%;
		text-decoration: none;
	    border: 0px solid ;
	    background-color:#ff8080;
        font-size: 25px;
        color: black;
        border-radius: 10px;
        text-align: center;
        font-family: courier new;
        padding-top: 6px;
        padding-bottom: 6px;
outline:none;
	}
</style></head>

<body>
<form action="index.php">
<p>
	<span style="border:0 solid red;background:red;box-shadow:5px 7px #efefef;color:white;font-size:25px;padding:15px;"><b>ABOUT US</b></span>
</p>
<div> 
<pre>
<textarea rows="22" cols="80" name="about" face="Comic Sans MS" >
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Airline reservation systems (ARS) are part of the so-called passenger service 
systems (PSS), which are applications supporting the direct contact with the passenger.ARS  eventually evolved into the computer reservations system (CRS). A 
computer reservation system is used for the reservations of a particular airline and interfaces with a global distribution system (GDS) which  supports travel agencies and other distribution channels in making 
reservations for most major airlines in a single.<br>Airline reservation systems incorporate airline schedules, fare tariffs, passenger 
reservations and ticket records. An airline's direct distribution works  within their own reservation system, as well as pushing out information 
to the GDS.The second type of direct distribution channel are consumers  who use the internet or mobile applications to make their own 
reservations. Travel agencies and other indirect distribution channels  access the same GDS as those accessed by the airline reservation 
systems, and all messaging is transmitted by a standardized messaging  system that functions on two types of messaging that transmit on SITA's 
high level network (HLN). These messaging types are called Type A 
[usually EDIFACT format] for real time interactive communication and 
Type B [TTY] for informational and booking type of messages. Message 
construction standards set by IATA and ICAO, are global, and apply to 
more than air transportation. Since airline reservation systems are 
business critical applications, and they are functionally quite complex,
 the operation of an in-house airline reservation system is relatively 
expensive. <br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Reservation
 systems may host "ticket-less" airlines and "hybrid" airlines that use 
e-ticketing in addition to ticket-less to accommodate code-shares and 
interlines.

In addition to these "standardized" GDS, some airlines have proprietary 
versions which they use to run their flight operations. A few examples 
are Delta's OSS and Deltamatic systems and EDS SHARES. SITA Reservations
 remains the largest neutral multi-host airline reservations system, 
with over 100 airlines currently managing inventory. 
    <br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Users
 access an airline’s inventory through an availability display. It 
contains all offered flights for a particular city-pair with their 
available seats in the different booking classes. This display contains 
flights which are operated by the airline itself as well as code share 
flights which are operated in co-operation with another airline. If the 
city pair is not one on which the airline offers service, it may display
 a connection using its own flights or display the flights of other 
airlines. The availability of seats of other airlines is updated through
 standard industry interfaces. Depending on the type of co-operation, it
 supports access to the last seat (last seat availability) in real-time.

 </textarea>
</pre>
	</div>

<button>HOME</button>
</form>
</body></html>