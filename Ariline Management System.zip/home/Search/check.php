<?php
$var1 = $_POST['fidd'];
echo $var1;
//http://localhost/Takeoff/home/Details/index.php
?>
