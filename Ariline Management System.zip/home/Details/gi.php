<html>
<style>

	p{
		font-size: 40px;
		font-weight: 500px;

		text-align: center;
	}

	button{
		position:relative;
		left:60%;
		padding:30px;
		text-decoration: none;
	    border: 0px solid ;
	    background-color:red;
		box-shadow:3px 3px black;
        font-size: 25px;
        color: black;
        border-radius: 10px;
        text-align: center;
        font-family: courier new;
        padding-top: 6px;
        padding-bottom: 6px;
outline:none;
	}
	body{

		background-image: url("airport2.jpg");
		background-size:cover;
	}
	div
	{
		text-align: center;
	}

button:hover
	{
cursor:pointer;
		border-radius: 10px;
		background-color: white;
	}

.mid
{
background:#000000;
position:relative;
top:15%;
left:25%;
width:600px;
height:400px;
padding:50px;
border:1px solid black;
border-radius:20px;
background:rgba(51,51,51,0.3);
}

</style>
<body>



<form action="../index.php">
<p>
		<br><br><font face="SF Burlington Script SC" color="black"><b>&nbsp;THANK&nbsp;&nbsp;&nbsp;YOU !!!!!</b></font>
		<font face="SF Burlington Script SC" color="black" ><br><b>&nbsp;for booking TICKET&nbsp;&nbsp;&nbsp;in TAKEOFF AIRLINES </b></font>
				<font face="SF Burlington Script SC" color="black" ><br><b>&nbsp;your SAFETY is &nbsp;&nbsp;our priority&nbsp;&nbsp;&nbsp;</b></font>
<font face="SF Burlington Script SC" color="black" ><br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font>
<font face="SF Burlington Script SC" color="black" ><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font>
	</p>

		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button align="center"><font face="courier new"><b>HOME</b></font></button>&nbsp;&nbsp;
</form>


</body>
</html>
