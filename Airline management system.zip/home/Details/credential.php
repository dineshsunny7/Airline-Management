<?php 

$var11=$_SESSION['mob'];
	/*Enter your API_KEY*/
	define("API_KEY", 'A5TiyiKpnj4-qmCgpshOqvVIwKMMftllvCdVklqfJy');

	/*You can enter mobile number here*/
	define("MOBILE", '$var1');
 ?>