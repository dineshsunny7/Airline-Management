<?php
session_destroy();
header("Location:http://localhost/takeoff/home/main/main_page.php#");
?>